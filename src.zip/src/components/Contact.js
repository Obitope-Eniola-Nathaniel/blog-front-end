// Contact.js
import React from "react";
const Contact = () => <h2>Contact Page</h2>;
export default Contact;
