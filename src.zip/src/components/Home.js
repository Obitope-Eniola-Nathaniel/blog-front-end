// Home.js
import React from "react";
const Home = () => <h2>Home Page</h2>;
export default Home;
